// server.js

const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const database = require('./database'); // Importer le module database

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Route pour ajouter un produit
app.post('/api/produits', (req, res) => {
    const { id, nom, quantite, dateExp } = req.body;
    database.ajouterProduit({ id, nom, quantite, dateExp }, (err) => {
        if (err) {
            return res.status(500).json({ message: 'Erreur lors de l\'ajout du produit.' });
        }
        res.status(201).json({ message: 'Produit ajouté avec succès' });
    });
});

// Route pour supprimer un produit par ID
app.delete('/api/produits/:id', (req, res) => {
    const id = parseInt(req.params.id);
    database.supprimerProduit(id, (err) => {
        if (err) {
            return res.status(500).json({ message: 'Erreur lors de la suppression du produit.' });
        }
        res.json({ message: 'Produit supprimé avec succès' });
    });
});

// Route pour obtenir tous les produits
app.get('/api/produits', (req, res) => {
    database.obtenirProduits((err, rows) => {
        if (err) {
            return res.status(500).json({ message: 'Erreur lors de la récupération des produits.' });
        }
        res.json(rows);
    });
});

// Démarrer le serveur
app.listen(PORT, () => {
    console.log(`Serveur en cours d'exécution sur http://localhost:${PORT}`);
});
