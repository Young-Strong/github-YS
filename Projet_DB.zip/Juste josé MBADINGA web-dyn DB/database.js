// database.js

const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Créer ou ouvrir une base de données SQLite
const dbPath = path.join(__dirname, 'pharmacie.db');
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Erreur lors de l\'ouverture de la base de données:', err.message);
    } else {
        console.log('Connecté à la base de données SQLite.');
        // Créer la table si elle n'existe pas déjà
        db.run(`CREATE TABLE IF NOT EXISTS produits (
            id INTEGER PRIMARY KEY,
            nom TEXT NOT NULL,
            quantite INTEGER NOT NULL,
            dateExp TEXT NOT NULL
        )`, (err) => {
            if (err) {
                console.error('Erreur lors de la création de la table:', err.message);
            }
        });
    }
});

// Fonction pour ajouter un produit
const ajouterProduit = (produit, callback) => {
    const { id, nom, quantite, dateExp } = produit;
    const sql = 'INSERT INTO produits (id, nom, quantite, dateExp) VALUES (?, ?, ?, ?)';
    db.run(sql, [id, nom, quantite, dateExp], function(err) {
        callback(err, this.lastID);
    });
};

// Fonction pour supprimer un produit par ID
const supprimerProduit = (id, callback) => {
    const sql = 'DELETE FROM produits WHERE id = ?';
    db.run(sql, id, function(err) {
        callback(err);
    });
};

// Fonction pour obtenir tous les produits
const obtenirProduits = (callback) => {
    const sql = 'SELECT * FROM produits';
    db.all(sql, [], (err, rows) => {
        callback(err, rows);
    });
};

// Exporter les fonctions
module.exports = {
    ajouterProduit,
    supprimerProduit,
    obtenirProduits,
};
