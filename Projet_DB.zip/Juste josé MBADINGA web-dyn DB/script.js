$(document).ready(function() {
    // Fonction pour ajouter un produit
    $('#stockForm').on('submit', function(event) {
        event.preventDefault();
        const id = $('#idProduit').val();
        const nom = $('#nomProduit').val();
        const quantite = $('#quantite').val();
        const dateExp = $('#datePicker').val();

        $.post('http://localhost:3000/api/produits', { id, nom, quantite, dateExp })
            .done(function(data) {
                $('#message').html(`<div class='alert alert-success'>${data.message}</div>`);
                $('#stockForm').trigger("reset");
            })
            .fail(function() {
                $('#message').html(`<div class='alert alert-danger'>Erreur lors de l'ajout du produit.</div>`);
            });
    });

    // Fonction pour supprimer un produit (exemple)
    $('#supprimerBtn').click(function() {
        const id = $('#idProduit').val();
        $.ajax({
            url: `http://localhost:3000/api/produits/${id}`,
            type: 'DELETE',
            success: function(data) {
                $('#message').html(`<div class='alert alert-warning'>${data.message}</div>`);
                $('#stockForm').trigger("reset");
            },
            error: function() {
                $('#message').html(`<div class='alert alert-danger'>Erreur lors de la suppression du produit.</div>`);
            }
        });
    });

    // Fonction d'annulation
    $('#annulerBtn').click(function() {
        $('#message').html(`<div class='alert alert-info'>Ajout annulé.</div>`);
        $('#stockForm').trigger("reset");
    });
});
